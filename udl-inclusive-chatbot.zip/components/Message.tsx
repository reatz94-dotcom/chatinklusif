
import React from 'react';
import { ChatMessage, ChatMessageType, Source } from '../types';

interface MessageProps {
  message: ChatMessage;
  onPlayAudio: (id: string) => void;
  onStopAudio: (id: string) => void;
}

const Message: React.FC<MessageProps> = ({ message, onPlayAudio, onStopAudio }) => {
  const isUser = message.sender === ChatMessageType.USER;
  const isBot = message.sender === ChatMessageType.BOT;
  const isError = message.sender === ChatMessageType.ERROR;

  const messageClasses = isUser
    ? 'bg-blue-500 text-white self-end'
    : isBot
      ? 'bg-gray-200 text-gray-800 self-start'
      : 'bg-red-100 text-red-700 self-start border border-red-300';

  const timeString = message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const handleAudioButtonClick = () => {
    if (message.audioPlaying) {
      onStopAudio(message.id);
    } else {
      onPlayAudio(message.id);
    }
  };

  return (
    <div className={`flex flex-col max-w-lg p-3 rounded-lg my-2 ${messageClasses}`}>
      <div className="flex items-center justify-between mb-1">
        <span className="font-semibold text-sm">
          {isUser ? 'Anda' : isBot ? 'Bot UDL' : 'Error'}
        </span>
        <span className="text-xs opacity-75">{timeString}</span>
      </div>
      <p className="text-base whitespace-pre-wrap">{message.text}</p>
      {isBot && message.audioBlob && (
        <div className="flex items-center mt-2">
          <button
            onClick={handleAudioButtonClick}
            className={`flex items-center justify-center p-1 rounded-full ${message.audioPlaying ? 'bg-red-400' : 'bg-green-500'} text-white focus:outline-none focus:ring-2 focus:ring-offset-2 ${message.audioPlaying ? 'focus:ring-red-500' : 'focus:ring-green-600'}`}
            aria-label={message.audioPlaying ? 'Stop audio' : 'Play audio'}
          >
            {message.audioPlaying ? (
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v13.5m-7.5-13.5v13.5" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.362 1.62-1.093l.305.116a.993.993 0 01.785.903v8.598a.993.993 0 01-.785.903l-.305.116c-.703.269-1.62-.237-1.62-1.093V5.653zM12.75 4.004c1.11-.384 2.233.214 2.65 1.121l.245.513a1.125 1.125 0 001.458.43l.534-.149c.815-.228 1.666.14 2.033.913.37.778.093 1.704-.678 2.05L16.746 9.2c-.678.325-1.123 1.096-1.123 1.901v2.969c0 .806.445 1.576 1.123 1.901l1.402.677c.77.373 1.048 1.3.678 2.07-.367.772-1.218 1.14-2.033.913l-.534-.149a1.125 1.125 0 00-1.458.43l-.245.513c-.417.907-1.54 1.499-2.65 1.121v-15.6Z" />
              </svg>
            )}
            <span className="ml-1 text-sm">{message.audioPlaying ? 'Stop' : 'Play'}</span>
          </button>
        </div>
      )}
      {message.sources && message.sources.length > 0 && (
        <div className="mt-2 pt-2 border-t border-gray-300">
          <p className="text-sm font-medium text-gray-600 mb-1">Sumber:</p>
          <ul className="list-disc list-inside text-xs text-gray-600">
            {message.sources.map((source: Source, index: number) => (
              <li key={index} className="truncate">
                <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                  {source.title || source.uri}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Message;
