
export const GEMINI_MODEL_FLASH_LITE = 'gemini-2.5-flash-lite';
export const GEMINI_MODEL_FLASH_SEARCH = 'gemini-3-flash-preview'; // For Search Grounding
export const GEMINI_MODEL_PRO_THINKING = 'gemini-3-pro-preview'; // For complex queries with thinking budget
export const GEMINI_MODEL_TTS = 'gemini-2.5-flash-preview-tts';

// Audio Context settings for TTS
export const AUDIO_SAMPLE_RATE_INPUT = 16000; // For microphone input (if implemented)
export const AUDIO_SAMPLE_RATE_OUTPUT = 24000; // For TTS output
export const AUDIO_NUM_CHANNELS = 1; // Mono audio
