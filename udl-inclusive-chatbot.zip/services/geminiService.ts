
import { GoogleGenAI, Modality } from "@google/genai";
import {
  GEMINI_MODEL_FLASH_LITE,
  GEMINI_MODEL_FLASH_SEARCH,
  GEMINI_MODEL_PRO_THINKING,
  GEMINI_MODEL_TTS,
  AUDIO_SAMPLE_RATE_OUTPUT,
  AUDIO_NUM_CHANNELS
} from '../constants';
import { decode, decodeAudioData } from './audioUtils';
import { Source } from '../types';

interface GenerateContentResult {
  text: string;
  sources?: Source[];
  audioBlob?: Blob; // For TTS results
}

// Function to get API key (assumed to be from process.env.API_KEY)
const getApiKey = (): string => {
  if (typeof process === 'undefined' || !process.env || !process.env.API_KEY) {
    console.error("API_KEY is not defined. Ensure it's set in the environment.");
    // In a real application, you might want to throw an error or handle this more gracefully.
    // For this example, we'll return an empty string, but API calls will likely fail.
    return '';
  }
  return process.env.API_KEY;
};

// Global AudioContext for TTS playback
let outputAudioContext: AudioContext | null = null;
let nextStartTime = 0;
const playingSources = new Set<AudioBufferSourceNode>(); // Track currently playing audio sources

// Initializes a shared AudioContext or returns the existing one
function getOutputAudioContext(): AudioContext {
  if (!outputAudioContext) {
    // FIX: Remove deprecated webkitAudioContext, as AudioContext is now widely supported.
    outputAudioContext = new AudioContext({ sampleRate: AUDIO_SAMPLE_RATE_OUTPUT });
  }
  return outputAudioContext;
}

/**
 * Converts text to speech using the Gemini TTS model.
 * @param text The text to convert to speech.
 * @returns A Promise that resolves with an AudioBuffer.
 */
export async function textToSpeech(text: string): Promise<AudioBuffer> {
  const apiKey = getApiKey();
  const ai = new GoogleGenAI({ apiKey });

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL_TTS,
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' }, // Or 'Zephyr', 'Puck', 'Charon', 'Fenrir'
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      throw new Error('No audio data received from TTS API.');
    }

    const audioContext = getOutputAudioContext();
    const audioBuffer = await decodeAudioData(
      decode(base64Audio),
      audioContext,
      AUDIO_SAMPLE_RATE_OUTPUT,
      AUDIO_NUM_CHANNELS,
    );

    return audioBuffer;
  } catch (error) {
    console.error("Error converting text to speech:", error);
    throw error;
  }
}

/**
 * Plays an AudioBuffer using the shared AudioContext.
 * @param audioBuffer The AudioBuffer to play.
 * @param onEnded Callback function when audio playback ends.
 */
export function playAudioBuffer(audioBuffer: AudioBuffer, onEnded: () => void): void {
  const audioContext = getOutputAudioContext();
  const source = audioContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(audioContext.destination);

  source.addEventListener('ended', () => {
    playingSources.delete(source);
    onEnded();
  });

  // Stop all currently playing sources before starting a new one
  for (const prevSource of playingSources.values()) {
    try {
      prevSource.stop();
    } catch (e) {
      console.warn("Could not stop previous audio source:", e);
    }
    playingSources.delete(prevSource);
  }

  // Schedule playback
  nextStartTime = Math.max(nextStartTime, audioContext.currentTime);
  source.start(nextStartTime);
  nextStartTime += audioBuffer.duration;
  playingSources.add(source);
}

/**
 * Sends a message to the Gemini model and gets a text response, with optional search grounding or complex thinking.
 * @param prompt The user's prompt.
 * @param modelType The type of model to use ('flash-lite', 'flash-search', 'pro-thinking').
 * @returns A Promise that resolves with the generated text and any source links.
 */
export async function sendMessageToGemini(
  prompt: string,
  modelType: 'flash-lite' | 'flash-search' | 'pro-thinking'
): Promise<GenerateContentResult> {
  const apiKey = getApiKey();
  const ai = new GoogleGenAI({ apiKey });

  let modelName: string;
  let config: any = {}; // Use any for config to allow flexible properties

  switch (modelType) {
    case 'flash-lite':
      modelName = GEMINI_MODEL_FLASH_LITE;
      break;
    case 'flash-search':
      modelName = GEMINI_MODEL_FLASH_SEARCH;
      config.tools = [{ googleSearch: {} }];
      break;
    case 'pro-thinking':
      modelName = GEMINI_MODEL_PRO_THINKING;
      config.thinkingConfig = { thinkingBudget: 32768 };
      break;
    default:
      modelName = GEMINI_MODEL_FLASH_LITE;
      break;
  }

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: config,
    });

    const text = response.text || "No response generated.";
    const result: GenerateContentResult = { text };

    // Extract sources if googleSearch was used
    if (modelType === 'flash-search' && response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
      const sources: Source[] = [];
      for (const chunk of response.candidates[0].groundingMetadata.groundingChunks) {
        if (chunk.web?.uri) {
          sources.push({
            uri: chunk.web.uri,
            title: chunk.web.title || new URL(chunk.web.uri).hostname,
          });
        }
      }
      result.sources = sources;
    }

    return result;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
      throw new Error(`Failed to get response from AI: ${error.message}`);
    }
    throw new Error("An unknown error occurred while contacting the AI.");
  }
}
