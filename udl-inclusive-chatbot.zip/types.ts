
export enum ChatMessageType {
  USER = 'user',
  BOT = 'bot',
  ERROR = 'error',
}

export interface Source {
  uri: string;
  title?: string;
}

export interface ChatMessage {
  id: string;
  sender: ChatMessageType;
  text: string;
  timestamp: Date;
  audioBlob?: Blob; // Blob for the audio data
  audioPlaying?: boolean;
  sources?: Source[]; // Links from Google Search grounding
}
